export default function MembershipCard({ plan, onSelect }) {
  return (
    <div className={`relative rounded-2xl p-8 border transition-all duration-300 ${
      plan.popular
        ? 'bg-gradient-to-b from-gold-500/10 to-navy-900 border-gold-500 shadow-lg shadow-gold-500/10'
        : 'bg-navy-900 border-white/10 hover:border-gold-500/30'
    }`}>
      {plan.popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="bg-gold-500 text-white text-xs font-bold px-4 py-1.5 rounded-full tracking-wider">
            MOST POPULAR
          </span>
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-white font-serif text-2xl font-bold mb-1">{plan.name}</h3>
        <p className="text-gray-400 text-sm">{plan.description}</p>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-1">
          <span className="text-gold-400 text-lg">₹</span>
          <span className="text-white text-4xl font-bold">
            {plan.price?.toLocaleString('en-IN')}
          </span>
          <span className="text-gray-400 text-sm ml-1">/ year</span>
        </div>
      </div>

      <ul className="space-y-3 mb-8">
        {plan.features?.map((feature, i) => (
          <li key={i} className="flex items-start gap-3">
            <svg className="w-5 h-5 text-gold-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <span className="text-gray-300 text-sm">{feature}</span>
          </li>
        ))}
      </ul>

      <button
        onClick={() => onSelect?.(plan)}
        className={`w-full py-3 rounded-xl font-semibold text-sm transition-all duration-200 ${
          plan.popular
            ? 'bg-gold-500 hover:bg-gold-600 text-white'
            : 'border border-gold-500 text-gold-500 hover:bg-gold-500 hover:text-white'
        }`}
      >
        Get Started
      </button>
    </div>
  )
}
