export default function EventCard({ event }) {
  const date = new Date(event.eventDate)

  return (
    <div className="card group cursor-pointer overflow-hidden">
      {event.imageUrl && (
        <div className="h-48 -mx-6 -mt-6 mb-5 overflow-hidden">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      )}

      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <span className="bg-gold-500/10 text-gold-400 text-xs font-medium px-3 py-1 rounded-full border border-gold-500/20">
          {event.category}
        </span>
        {event.membersOnly && (
          <span className="bg-white/5 text-gray-400 text-xs px-3 py-1 rounded-full border border-white/10">
            Members Only
          </span>
        )}
      </div>

      <h3 className="text-white font-semibold text-lg mb-2 group-hover:text-gold-400 transition-colors line-clamp-2">
        {event.title}
      </h3>
      <p className="text-gray-400 text-sm mb-4 line-clamp-2">{event.shortDescription}</p>

      <div className="border-t border-white/10 pt-4 space-y-2">
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <svg className="w-4 h-4 text-gold-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <span>{date.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <svg className="w-4 h-4 text-gold-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <span className="truncate">{event.venue}, {event.city}</span>
        </div>
        {event.maxAttendees && (
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <svg className="w-4 h-4 text-gold-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span>{event.currentAttendees} / {event.maxAttendees} attending</span>
          </div>
        )}
      </div>
    </div>
  )
}
