import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="bg-navy-950 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-gold-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold font-serif text-lg">IB</span>
              </div>
              <div>
                <div className="text-white font-serif font-bold text-lg leading-none">IB Club India</div>
                <div className="text-gold-500 text-xs leading-none">Investors &amp; Business Leaders Network</div>
              </div>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              India's premier network connecting investors, entrepreneurs, and business leaders
              for meaningful collaboration and lasting growth.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-3">
              {[{ to: '/', label: 'Home' }, { to: '/events', label: 'Events' }, { to: '/membership', label: 'Membership' }].map(l => (
                <li key={l.to}>
                  <Link to={l.to} className="text-gray-400 hover:text-gold-400 text-sm transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li>Mumbai, Maharashtra, India</li>
              <li>info@ibclub.org</li>
              <li>+91 98765 43210</li>
            </ul>
            <div className="flex gap-4 mt-6">
              {['LinkedIn', 'Twitter', 'Instagram'].map(s => (
                <a key={s} href="#" className="text-gray-500 hover:text-gold-400 text-xs transition-colors">{s}</a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">© 2024 IB Club India. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
