import { useState, useEffect } from 'react'
import { eventService } from '../services/eventService'
import EventCard from '../components/EventCard'

const CATEGORIES = ['All', 'Summit', 'Workshop', 'Forum', 'Dinner', 'Networking']

export default function Events() {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState('All')
  const [error, setError] = useState(null)

  useEffect(() => {
    setLoading(true)
    setError(null)
    const cat = activeCategory === 'All' ? undefined : activeCategory
    eventService.getAll(cat)
      .then(setEvents)
      .catch(() => setError('Failed to load events. Please try again.'))
      .finally(() => setLoading(false))
  }, [activeCategory])

  return (
    <div className="min-h-screen pt-20">
      <div className="bg-gradient-to-b from-navy-900 to-navy-950 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-gold-500 text-sm font-semibold uppercase tracking-widest mb-4">Events</div>
          <h1 className="font-serif text-5xl font-bold text-white mb-4">Events &amp; Programmes</h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Exclusive events, workshops, and forums designed to foster meaningful connections
            among India's business elite.
          </p>
        </div>
      </div>

      <div className="sticky top-20 bg-navy-950/95 backdrop-blur-md border-b border-white/10 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                  activeCategory === cat
                    ? 'bg-gold-500 text-white'
                    : 'bg-navy-900 text-gray-400 hover:text-white border border-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-10 h-10 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : error ? (
          <div className="text-center py-20 text-red-400">{error}</div>
        ) : events.length === 0 ? (
          <div className="text-center py-20 text-gray-400">No events found in this category.</div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map(e => <EventCard key={e.id} event={e} />)}
          </div>
        )}
      </div>
    </div>
  )
}
