import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { eventService } from '../services/eventService'
import EventCard from '../components/EventCard'

const STATS = [
  { value: '5,000+', label: 'Members' },
  { value: '200+', label: 'Events per Year' },
  { value: '30+', label: 'Cities' },
  { value: '₹500Cr+', label: 'Deals Facilitated' },
]

const FEATURES = [
  { icon: '🤝', title: 'Curated Network', desc: 'Every member is personally vetted for quality and intent' },
  { icon: '🎯', title: 'Deal Flow', desc: 'Access exclusive investment opportunities before they go public' },
  { icon: '🎓', title: 'Knowledge', desc: 'Learn from India\'s most accomplished business leaders' },
  { icon: '🌐', title: 'Pan-India', desc: 'Network spanning 30+ cities across India' },
]

const TESTIMONIALS = [
  { name: 'Rajesh Kumar', role: 'MD, Apex Ventures', initials: 'RK', text: 'IB Club has been instrumental in my investment journey. The quality of connections and insights I\'ve gained are unparalleled in India.' },
  { name: 'Priya Sharma', role: 'Founder, TechBridge Solutions', initials: 'PS', text: 'The networking events opened doors I didn\'t know existed. A must-join for serious business leaders who want to make things happen.' },
  { name: 'Anil Mehta', role: 'Angel Investor & Serial Entrepreneur', initials: 'AM', text: 'In 3 years of membership I\'ve co-invested in 7 startups and built partnerships worth far more than the membership fee.' },
]

export default function Home() {
  const [events, setEvents] = useState([])

  useEffect(() => {
    eventService.getAll().then(d => setEvents(d.slice(0, 3))).catch(() => {})
  }, [])

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-navy-950 via-navy-900 to-[#0D1F40]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(201,168,76,0.08),transparent_60%)]" />
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px,rgba(255,255,255,0.04) 1px,transparent 0)', backgroundSize: '40px 40px' }} />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
          <div className="inline-flex items-center gap-2 bg-gold-500/10 border border-gold-500/20 rounded-full px-4 py-2 mb-8">
            <div className="w-2 h-2 bg-gold-500 rounded-full animate-pulse" />
            <span className="text-gold-400 text-sm font-medium">India's Premier Business Network</span>
          </div>

          <h1 className="font-serif text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Where India's{' '}
            <span className="text-gold-500">Investors</span>
            <br />&amp; Leaders Connect
          </h1>

          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Join India's most exclusive network of investors, entrepreneurs, and business leaders.
            Build meaningful relationships that accelerate your growth.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="btn-gold text-base px-8 py-4">
              Apply for Membership
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
            <Link to="/events" className="btn-outline-gold text-base px-8 py-4">View Events</Link>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-navy-900 border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map(s => (
              <div key={s.label} className="text-center">
                <div className="text-3xl md:text-4xl font-bold font-serif text-gold-500 mb-2">{s.value}</div>
                <div className="text-gray-400 text-sm">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <div className="text-gold-500 text-sm font-semibold uppercase tracking-widest mb-4">About IB Club</div>
            <h2 className="section-title mb-6">Building India's Most Powerful Business Ecosystem</h2>
            <p className="text-gray-400 leading-relaxed mb-5">
              IB Club India was founded with a singular vision: to create a curated ecosystem where India's
              brightest business minds connect, collaborate, and create lasting value.
            </p>
            <p className="text-gray-400 leading-relaxed mb-8">
              Our members include serial entrepreneurs, institutional investors, family offices, corporate
              leaders, and emerging business talents — all united by the drive to build and grow.
            </p>
            <Link to="/membership" className="btn-gold">
              Explore Membership
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {FEATURES.map(f => (
              <div key={f.title} className="card">
                <div className="text-3xl mb-3">{f.icon}</div>
                <div className="text-white font-semibold mb-1 text-sm">{f.title}</div>
                <div className="text-gray-400 text-xs leading-relaxed">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Events Preview */}
      {events.length > 0 && (
        <section className="py-24 bg-navy-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-12 gap-4">
              <div>
                <div className="text-gold-500 text-sm font-semibold uppercase tracking-widest mb-2">Upcoming</div>
                <h2 className="section-title">Events &amp; Programmes</h2>
              </div>
              <Link to="/events" className="btn-outline-gold text-sm py-2">
                View All
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </Link>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {events.map(e => <EventCard key={e.id} event={e} />)}
            </div>
          </div>
        </section>
      )}

      {/* Testimonials */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-gold-500 text-sm font-semibold uppercase tracking-widest mb-4">Testimonials</div>
          <h2 className="section-title">What Our Members Say</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map(t => (
            <div key={t.name} className="card">
              <div className="text-gold-500 text-4xl font-serif mb-4">"</div>
              <p className="text-gray-300 text-sm leading-relaxed mb-6">{t.text}</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gold-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-gold-400 font-bold text-sm">{t.initials}</span>
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-gray-400 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-gradient-to-r from-navy-900 via-[#0D1F40] to-navy-900 border-y border-white/10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title mb-4">Ready to Join India's Elite Business Network?</h2>
          <p className="text-gray-400 text-lg mb-8">
            Apply for membership today and unlock exclusive access to events, deals, and connections.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="btn-gold text-base px-8 py-4">
              Apply for Membership
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
            <Link to="/events" className="btn-outline-gold text-base px-8 py-4">View Events</Link>
          </div>
        </div>
      </section>
    </div>
  )
}
