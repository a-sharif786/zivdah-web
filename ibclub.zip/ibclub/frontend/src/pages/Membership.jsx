import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { membershipService } from '../services/membershipService'
import MembershipCard from '../components/MembershipCard'
import { useAuth } from '../context/AuthContext'

const BENEFITS = [
  { icon: '🤝', title: 'Exclusive Networking', desc: 'Connect with 5,000+ vetted investors and business leaders across India' },
  { icon: '🎯', title: 'Deal Flow Access', desc: 'Get access to curated investment opportunities and co-investment deals' },
  { icon: '📚', title: 'Knowledge Platform', desc: 'Expert-led workshops, masterclasses, and curated business insights' },
  { icon: '🏆', title: 'Recognition', desc: 'Be part of an elite community recognized across Indian business circles' },
  { icon: '🌐', title: 'Pan-India Presence', desc: 'Events and members across 30+ cities pan-India' },
  { icon: '💼', title: 'Business Opportunities', desc: 'Discover partnership, JV, and collaboration opportunities through the network' },
]

const FAQS = [
  { q: 'How is membership renewed?', a: 'Memberships are annual and can be renewed online or by contacting our membership team 30 days before expiry.' },
  { q: 'Can I upgrade my membership?', a: 'Yes, you can upgrade to a higher tier at any time. You only pay the difference for the remaining period.' },
  { q: 'Are memberships transferable?', a: 'IB Club memberships are individual and non-transferable. Corporate plans are available for teams of 3+.' },
  { q: 'Is there a joining fee?', a: 'There is a one-time registration fee of ₹2,000 for all new members, waived during promotional periods.' },
]

export default function Membership() {
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(true)
  const [openFaq, setOpenFaq] = useState(null)
  const { user } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    membershipService.getPlans().then(setPlans).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const handleSelect = (plan) => {
    if (!user) navigate('/register')
    else alert(`You selected the ${plan.name} plan. Our team will contact you shortly to complete the process.`)
  }

  return (
    <div className="min-h-screen pt-20">
      <div className="bg-gradient-to-b from-navy-900 to-navy-950 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-gold-500 text-sm font-semibold uppercase tracking-widest mb-4">Membership</div>
          <h1 className="font-serif text-5xl font-bold text-white mb-4">Choose Your Plan</h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Select the plan that best suits your networking and investment goals.
            All plans include access to our core community.
          </p>
        </div>
      </div>

      {/* Plans */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-10 h-10 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8 items-start pt-6">
            {plans.map(p => <MembershipCard key={p.id} plan={p} onSelect={handleSelect} />)}
          </div>
        )}
      </section>

      {/* Benefits */}
      <section className="py-20 bg-navy-900 border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="text-gold-500 text-sm font-semibold uppercase tracking-widest mb-4">Why Join</div>
            <h2 className="section-title">Member Benefits</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {BENEFITS.map(b => (
              <div key={b.title} className="card">
                <div className="text-4xl mb-4">{b.icon}</div>
                <h3 className="text-white font-semibold text-lg mb-2">{b.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="section-title">Frequently Asked Questions</h2>
        </div>
        <div className="space-y-3">
          {FAQS.map((faq, i) => (
            <div key={i} className="card cursor-pointer" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
              <div className="flex justify-between items-center">
                <h4 className="text-white font-semibold text-sm pr-4">{faq.q}</h4>
                <svg className={`w-5 h-5 text-gold-500 flex-shrink-0 transition-transform ${openFaq === i ? 'rotate-180' : ''}`}
                  fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
              {openFaq === i && <p className="text-gray-400 text-sm mt-3 leading-relaxed">{faq.a}</p>}
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
