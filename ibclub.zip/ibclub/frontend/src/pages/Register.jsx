import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const FIELDS = [
  { name: 'firstName', label: 'First Name', placeholder: 'Raj', required: true, half: true },
  { name: 'lastName', label: 'Last Name', placeholder: 'Kumar', required: true, half: true },
  { name: 'email', label: 'Email Address', type: 'email', placeholder: 'raj@example.com', required: true },
  { name: 'password', label: 'Password', type: 'password', placeholder: 'Minimum 8 characters', required: true },
  { name: 'phone', label: 'Phone Number', placeholder: '+91 99999 99999' },
  { name: 'company', label: 'Company / Organisation', placeholder: 'Your company name' },
  { name: 'designation', label: 'Designation / Role', placeholder: 'Managing Director' },
]

export default function Register() {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', password: '', phone: '', company: '', designation: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { register } = useAuth()
  const navigate = useNavigate()

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async e => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await register(form)
      navigate('/')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const halfFields = FIELDS.filter(f => f.half)
  const fullFields = FIELDS.filter(f => !f.half)

  return (
    <div className="min-h-screen flex items-center justify-center pt-20 pb-12 px-4">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gold-500/10 border border-gold-500/20 rounded-full mb-4">
            <div className="w-10 h-10 bg-gold-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold font-serif text-lg">IB</span>
            </div>
          </div>
          <h1 className="text-2xl font-bold font-serif text-white mb-2">Join IB Club India</h1>
          <p className="text-gray-400 text-sm">Create your account to access India's premier business network</p>
        </div>

        <div className="card">
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 mb-5 text-red-400 text-sm">
              {error}
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {halfFields.map(f => (
                <div key={f.name}>
                  <label className="block text-gray-300 text-sm font-medium mb-2">{f.label}</label>
                  <input name={f.name} type={f.type || 'text'} value={form[f.name]} onChange={handleChange}
                    required={f.required} placeholder={f.placeholder} className="input-field" />
                </div>
              ))}
            </div>
            {fullFields.map(f => (
              <div key={f.name}>
                <label className="block text-gray-300 text-sm font-medium mb-2">{f.label}</label>
                <input name={f.name} type={f.type || 'text'} value={form[f.name]} onChange={handleChange}
                  required={f.required} placeholder={f.placeholder} className="input-field" />
              </div>
            ))}

            <div className="bg-gold-500/5 border border-gold-500/10 rounded-lg p-4 text-gray-400 text-xs leading-relaxed">
              By registering, you agree to our{' '}
              <a href="#" className="text-gold-400 hover:underline">Terms of Service</a> and{' '}
              <a href="#" className="text-gold-400 hover:underline">Privacy Policy</a>.
              Membership is subject to verification and approval.
            </div>

            <button type="submit" disabled={loading}
              className="btn-gold w-full justify-center py-3 disabled:opacity-50 disabled:cursor-not-allowed">
              {loading
                ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                : 'Create Account'}
            </button>
          </form>
        </div>

        <p className="text-center text-gray-400 text-sm mt-6">
          Already have an account?{' '}
          <Link to="/login" className="text-gold-400 hover:text-gold-300 font-medium">Sign In</Link>
        </p>
      </div>
    </div>
  )
}
