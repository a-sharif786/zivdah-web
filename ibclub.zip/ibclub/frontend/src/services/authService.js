import api from './api'

export const authService = {
  login: async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password })
    return data
  },
  register: async (formData) => {
    const { data } = await api.post('/auth/register', formData)
    return data
  },
}
