import api from './api'

export const membershipService = {
  getPlans: async () => {
    const { data } = await api.get('/membership-plans')
    return data
  },
}
