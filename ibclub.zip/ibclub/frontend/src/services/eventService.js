import api from './api'

export const eventService = {
  getAll: async (category) => {
    const params = category ? { category } : {}
    const { data } = await api.get('/events', { params })
    return data
  },
  getById: async (id) => {
    const { data } = await api.get(`/events/${id}`)
    return data
  },
}
