package com.ibclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbClubApplication {
    public static void main(String[] args) {
        SpringApplication.run(IbClubApplication.class, args);
    }
}
