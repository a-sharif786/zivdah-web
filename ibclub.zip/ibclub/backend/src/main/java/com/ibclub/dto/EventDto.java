package com.ibclub.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EventDto {
    private Long id;
    private String title;
    private String description;
    private String shortDescription;
    private String venue;
    private String city;
    private LocalDateTime eventDate;
    private LocalDateTime endDate;
    private String imageUrl;
    private String category;
    private Integer maxAttendees;
    private Integer currentAttendees;
    private Boolean membersOnly;
}
