package com.ibclub.service;

import com.ibclub.dto.EventDto;
import com.ibclub.model.Event;
import com.ibclub.repository.EventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository eventRepository;

    public Flux<EventDto> getAllEvents() {
        return eventRepository.findByActiveTrueOrderByEventDateDesc().map(this::toDto);
    }

    public Mono<EventDto> getEventById(Long id) {
        return eventRepository.findById(id)
                .switchIfEmpty(Mono.error(new RuntimeException("Event not found")))
                .map(this::toDto);
    }

    public Flux<EventDto> getEventsByCategory(String category) {
        return eventRepository.findByCategoryAndActiveTrue(category).map(this::toDto);
    }

    private EventDto toDto(Event e) {
        return EventDto.builder()
                .id(e.getId())
                .title(e.getTitle())
                .description(e.getDescription())
                .shortDescription(e.getShortDescription())
                .venue(e.getVenue())
                .city(e.getCity())
                .eventDate(e.getEventDate())
                .endDate(e.getEndDate())
                .imageUrl(e.getImageUrl())
                .category(e.getCategory())
                .maxAttendees(e.getMaxAttendees())
                .currentAttendees(e.getCurrentAttendees())
                .membersOnly(e.getMembersOnly())
                .build();
    }
}
