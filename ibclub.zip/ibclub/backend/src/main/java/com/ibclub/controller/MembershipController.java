package com.ibclub.controller;

import com.ibclub.dto.MembershipPlanDto;
import com.ibclub.service.MembershipService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/membership-plans")
@RequiredArgsConstructor
public class MembershipController {

    private final MembershipService membershipService;

    @GetMapping
    public Flux<MembershipPlanDto> getAll() {
        return membershipService.getAllPlans();
    }

    @GetMapping("/{id}")
    public Mono<MembershipPlanDto> getById(@PathVariable Long id) {
        return membershipService.getPlanById(id);
    }
}
