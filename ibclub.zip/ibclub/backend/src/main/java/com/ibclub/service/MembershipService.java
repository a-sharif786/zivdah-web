package com.ibclub.service;

import com.ibclub.dto.MembershipPlanDto;
import com.ibclub.model.MembershipPlan;
import com.ibclub.repository.MembershipPlanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MembershipService {

    private final MembershipPlanRepository membershipPlanRepository;

    public Flux<MembershipPlanDto> getAllPlans() {
        return membershipPlanRepository.findByActiveTrueOrderByPriceAsc().map(this::toDto);
    }

    public Mono<MembershipPlanDto> getPlanById(Long id) {
        return membershipPlanRepository.findById(id)
                .switchIfEmpty(Mono.error(new RuntimeException("Plan not found")))
                .map(this::toDto);
    }

    private MembershipPlanDto toDto(MembershipPlan p) {
        List<String> features = (p.getFeatures() != null && !p.getFeatures().isEmpty())
                ? Arrays.asList(p.getFeatures().split("\\|"))
                : List.of();
        return MembershipPlanDto.builder()
                .id(p.getId())
                .name(p.getName())
                .description(p.getDescription())
                .price(p.getPrice())
                .durationMonths(p.getDurationMonths())
                .features(features)
                .popular(p.getPopular())
                .build();
    }
}
