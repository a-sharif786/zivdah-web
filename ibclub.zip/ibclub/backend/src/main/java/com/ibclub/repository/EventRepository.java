package com.ibclub.repository;

import com.ibclub.model.Event;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface EventRepository extends R2dbcRepository<Event, Long> {
    Flux<Event> findByActiveTrueOrderByEventDateDesc();
    Flux<Event> findByCategoryAndActiveTrue(String category);
}
