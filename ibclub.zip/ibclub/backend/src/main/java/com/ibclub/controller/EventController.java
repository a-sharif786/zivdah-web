package com.ibclub.controller;

import com.ibclub.dto.EventDto;
import com.ibclub.service.EventService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventController {

    private final EventService eventService;

    @GetMapping
    public Flux<EventDto> getAll(@RequestParam(required = false) String category) {
        if (category != null && !category.isBlank()) {
            return eventService.getEventsByCategory(category);
        }
        return eventService.getAllEvents();
    }

    @GetMapping("/{id}")
    public Mono<EventDto> getById(@PathVariable Long id) {
        return eventService.getEventById(id);
    }
}
