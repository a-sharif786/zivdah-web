package com.ibclub.repository;

import com.ibclub.model.MembershipPlan;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface MembershipPlanRepository extends R2dbcRepository<MembershipPlan, Long> {
    Flux<MembershipPlan> findByActiveTrueOrderByPriceAsc();
}
